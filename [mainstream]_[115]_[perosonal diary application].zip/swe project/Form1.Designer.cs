﻿
namespace swe_project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userIdLabel = new System.Windows.Forms.Label();
            this.userTypeLabel = new System.Windows.Forms.Label();
            this.userTypeTxt = new System.Windows.Forms.TextBox();
            this.ageLabel = new System.Windows.Forms.Label();
            this.ageTxt = new System.Windows.Forms.TextBox();
            this.genderLabel = new System.Windows.Forms.Label();
            this.genderTxt = new System.Windows.Forms.TextBox();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.passwordTxt = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.emailTxt = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.lastNameTxt = new System.Windows.Forms.TextBox();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.firstNameTxt = new System.Windows.Forms.TextBox();
            this.addUserBtn = new System.Windows.Forms.Button();
            this.deleteUserBtn = new System.Windows.Forms.Button();
            this.updateUserBtn = new System.Windows.Forms.Button();
            this.userIdBox = new System.Windows.Forms.ComboBox();
            this.addPhoneBtn = new System.Windows.Forms.Button();
            this.phonesLabel = new System.Windows.Forms.Label();
            this.phonesBox = new System.Windows.Forms.ComboBox();
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.showPhonesBtn = new System.Windows.Forms.Button();
            this.userPhonesReportBtn = new System.Windows.Forms.Button();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // userIdLabel
            // 
            this.userIdLabel.AutoSize = true;
            this.userIdLabel.Location = new System.Drawing.Point(68, 101);
            this.userIdLabel.Name = "userIdLabel";
            this.userIdLabel.Size = new System.Drawing.Size(41, 13);
            this.userIdLabel.TabIndex = 1;
            this.userIdLabel.Text = "User Id";
            // 
            // userTypeLabel
            // 
            this.userTypeLabel.AutoSize = true;
            this.userTypeLabel.Location = new System.Drawing.Point(68, 284);
            this.userTypeLabel.Name = "userTypeLabel";
            this.userTypeLabel.Size = new System.Drawing.Size(56, 13);
            this.userTypeLabel.TabIndex = 3;
            this.userTypeLabel.Text = "User Type";
            // 
            // userTypeTxt
            // 
            this.userTypeTxt.Location = new System.Drawing.Point(132, 284);
            this.userTypeTxt.Name = "userTypeTxt";
            this.userTypeTxt.Size = new System.Drawing.Size(146, 20);
            this.userTypeTxt.TabIndex = 2;
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Location = new System.Drawing.Point(68, 259);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(26, 13);
            this.ageLabel.TabIndex = 5;
            this.ageLabel.Text = "Age";
            // 
            // ageTxt
            // 
            this.ageTxt.Location = new System.Drawing.Point(132, 257);
            this.ageTxt.Name = "ageTxt";
            this.ageTxt.Size = new System.Drawing.Size(146, 20);
            this.ageTxt.TabIndex = 4;
            // 
            // genderLabel
            // 
            this.genderLabel.AutoSize = true;
            this.genderLabel.Location = new System.Drawing.Point(68, 231);
            this.genderLabel.Name = "genderLabel";
            this.genderLabel.Size = new System.Drawing.Size(42, 13);
            this.genderLabel.TabIndex = 7;
            this.genderLabel.Text = "Gender";
            // 
            // genderTxt
            // 
            this.genderTxt.Location = new System.Drawing.Point(132, 231);
            this.genderTxt.Name = "genderTxt";
            this.genderTxt.Size = new System.Drawing.Size(146, 20);
            this.genderTxt.TabIndex = 6;
            // 
            // passwordLabel
            // 
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Location = new System.Drawing.Point(68, 205);
            this.passwordLabel.Name = "passwordLabel";
            this.passwordLabel.Size = new System.Drawing.Size(53, 13);
            this.passwordLabel.TabIndex = 9;
            this.passwordLabel.Text = "Password";
            // 
            // passwordTxt
            // 
            this.passwordTxt.Location = new System.Drawing.Point(132, 205);
            this.passwordTxt.Name = "passwordTxt";
            this.passwordTxt.Size = new System.Drawing.Size(146, 20);
            this.passwordTxt.TabIndex = 8;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(68, 179);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(31, 13);
            this.emailLabel.TabIndex = 11;
            this.emailLabel.Text = "email";
            // 
            // emailTxt
            // 
            this.emailTxt.Location = new System.Drawing.Point(132, 179);
            this.emailTxt.Name = "emailTxt";
            this.emailTxt.Size = new System.Drawing.Size(146, 20);
            this.emailTxt.TabIndex = 10;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(68, 153);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(58, 13);
            this.lastNameLabel.TabIndex = 13;
            this.lastNameLabel.Text = "Last Name";
            // 
            // lastNameTxt
            // 
            this.lastNameTxt.Location = new System.Drawing.Point(132, 153);
            this.lastNameTxt.Name = "lastNameTxt";
            this.lastNameTxt.Size = new System.Drawing.Size(146, 20);
            this.lastNameTxt.TabIndex = 12;
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(68, 127);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(57, 13);
            this.firstNameLabel.TabIndex = 15;
            this.firstNameLabel.Text = "First Name";
            // 
            // firstNameTxt
            // 
            this.firstNameTxt.Location = new System.Drawing.Point(132, 127);
            this.firstNameTxt.Name = "firstNameTxt";
            this.firstNameTxt.Size = new System.Drawing.Size(146, 20);
            this.firstNameTxt.TabIndex = 14;
            // 
            // addUserBtn
            // 
            this.addUserBtn.BackColor = System.Drawing.SystemColors.Menu;
            this.addUserBtn.Location = new System.Drawing.Point(343, 127);
            this.addUserBtn.Name = "addUserBtn";
            this.addUserBtn.Size = new System.Drawing.Size(87, 38);
            this.addUserBtn.TabIndex = 16;
            this.addUserBtn.Text = "Add User";
            this.addUserBtn.UseVisualStyleBackColor = false;
            this.addUserBtn.Click += new System.EventHandler(this.addUserBtn_Click);
            // 
            // deleteUserBtn
            // 
            this.deleteUserBtn.BackColor = System.Drawing.Color.DarkRed;
            this.deleteUserBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.deleteUserBtn.Location = new System.Drawing.Point(343, 257);
            this.deleteUserBtn.Name = "deleteUserBtn";
            this.deleteUserBtn.Size = new System.Drawing.Size(87, 39);
            this.deleteUserBtn.TabIndex = 17;
            this.deleteUserBtn.Text = "Delete User";
            this.deleteUserBtn.UseVisualStyleBackColor = false;
            this.deleteUserBtn.Click += new System.EventHandler(this.deleteUserBtn_Click);
            // 
            // updateUserBtn
            // 
            this.updateUserBtn.BackColor = System.Drawing.SystemColors.MenuBar;
            this.updateUserBtn.Location = new System.Drawing.Point(343, 193);
            this.updateUserBtn.Name = "updateUserBtn";
            this.updateUserBtn.Size = new System.Drawing.Size(87, 42);
            this.updateUserBtn.TabIndex = 18;
            this.updateUserBtn.Text = "Update User";
            this.updateUserBtn.UseVisualStyleBackColor = false;
            this.updateUserBtn.Click += new System.EventHandler(this.updateUserBtn_Click);
            // 
            // userIdBox
            // 
            this.userIdBox.FormattingEnabled = true;
            this.userIdBox.Location = new System.Drawing.Point(132, 101);
            this.userIdBox.Name = "userIdBox";
            this.userIdBox.Size = new System.Drawing.Size(146, 21);
            this.userIdBox.TabIndex = 19;
            this.userIdBox.SelectedIndexChanged += new System.EventHandler(this.userIdBox_SelectedIndexChanged);
            // 
            // addPhoneBtn
            // 
            this.addPhoneBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.addPhoneBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addPhoneBtn.Location = new System.Drawing.Point(696, 188);
            this.addPhoneBtn.Name = "addPhoneBtn";
            this.addPhoneBtn.Size = new System.Drawing.Size(90, 37);
            this.addPhoneBtn.TabIndex = 20;
            this.addPhoneBtn.Text = "Add Phone";
            this.addPhoneBtn.UseVisualStyleBackColor = false;
            this.addPhoneBtn.Click += new System.EventHandler(this.addPhoneBtn_Click);
            // 
            // phonesLabel
            // 
            this.phonesLabel.AutoSize = true;
            this.phonesLabel.Location = new System.Drawing.Point(556, 147);
            this.phonesLabel.Name = "phonesLabel";
            this.phonesLabel.Size = new System.Drawing.Size(43, 13);
            this.phonesLabel.TabIndex = 21;
            this.phonesLabel.Text = "Phones";
            // 
            // phonesBox
            // 
            this.phonesBox.FormattingEnabled = true;
            this.phonesBox.Location = new System.Drawing.Point(620, 144);
            this.phonesBox.Name = "phonesBox";
            this.phonesBox.Size = new System.Drawing.Size(146, 21);
            this.phonesBox.TabIndex = 22;
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.BackColor = System.Drawing.Color.LightCoral;
            this.welcomeLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.welcomeLabel.Font = new System.Drawing.Font("Modern No. 20", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.welcomeLabel.Location = new System.Drawing.Point(211, 25);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(402, 38);
            this.welcomeLabel.TabIndex = 23;
            this.welcomeLabel.Text = "Welcome to Users Form";
            this.welcomeLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // showPhonesBtn
            // 
            this.showPhonesBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.showPhonesBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.showPhonesBtn.Location = new System.Drawing.Point(600, 188);
            this.showPhonesBtn.Name = "showPhonesBtn";
            this.showPhonesBtn.Size = new System.Drawing.Size(90, 37);
            this.showPhonesBtn.TabIndex = 24;
            this.showPhonesBtn.Text = "Show Phones";
            this.showPhonesBtn.UseVisualStyleBackColor = false;
            this.showPhonesBtn.Click += new System.EventHandler(this.showPhonesBtn_Click);
            // 
            // userPhonesReportBtn
            // 
            this.userPhonesReportBtn.BackColor = System.Drawing.Color.SandyBrown;
            this.userPhonesReportBtn.Location = new System.Drawing.Point(326, 329);
            this.userPhonesReportBtn.Name = "userPhonesReportBtn";
            this.userPhonesReportBtn.Size = new System.Drawing.Size(143, 37);
            this.userPhonesReportBtn.TabIndex = 25;
            this.userPhonesReportBtn.Text = "User Phones Report";
            this.userPhonesReportBtn.UseVisualStyleBackColor = false;
            this.userPhonesReportBtn.Click += new System.EventHandler(this.userPhonesReportBtn_Click);
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Location = new System.Drawing.Point(27, 372);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new System.Drawing.Size(780, 347);
            this.crystalReportViewer1.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(833, 731);
            this.Controls.Add(this.crystalReportViewer1);
            this.Controls.Add(this.userPhonesReportBtn);
            this.Controls.Add(this.showPhonesBtn);
            this.Controls.Add(this.welcomeLabel);
            this.Controls.Add(this.phonesBox);
            this.Controls.Add(this.phonesLabel);
            this.Controls.Add(this.addPhoneBtn);
            this.Controls.Add(this.userIdBox);
            this.Controls.Add(this.updateUserBtn);
            this.Controls.Add(this.deleteUserBtn);
            this.Controls.Add(this.addUserBtn);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.firstNameTxt);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.lastNameTxt);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.emailTxt);
            this.Controls.Add(this.passwordLabel);
            this.Controls.Add(this.passwordTxt);
            this.Controls.Add(this.genderLabel);
            this.Controls.Add(this.genderTxt);
            this.Controls.Add(this.ageLabel);
            this.Controls.Add(this.ageTxt);
            this.Controls.Add(this.userTypeLabel);
            this.Controls.Add(this.userTypeTxt);
            this.Controls.Add(this.userIdLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label userIdLabel;
        private System.Windows.Forms.ComboBox userIdBox;
        private System.Windows.Forms.Label userTypeLabel;
        private System.Windows.Forms.TextBox userTypeTxt;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.TextBox ageTxt;
        private System.Windows.Forms.Label genderLabel;
        private System.Windows.Forms.TextBox genderTxt;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.TextBox passwordTxt;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.TextBox emailTxt;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox lastNameTxt;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.TextBox firstNameTxt;
        private System.Windows.Forms.Button addUserBtn;
        private System.Windows.Forms.Button deleteUserBtn;
        private System.Windows.Forms.Button updateUserBtn;
        private System.Windows.Forms.Label phonesLabel;
        private System.Windows.Forms.ComboBox phonesBox;
        private System.Windows.Forms.Button addPhoneBtn;
        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Button showPhonesBtn;
        private System.Windows.Forms.Button userPhonesReportBtn;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
    }
}

