﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace swe_project
{
    public partial class Form1 : Form
    {
        CrystalReport1 cr;
        string ordb = "Data source = orcl;User Id = scott; Password = scott;";
        OracleConnection con;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cr = new CrystalReport1();

            con = new OracleConnection(ordb);
            con.Open();

            OracleCommand cmd = new OracleCommand();
            cmd.Connection = con;
            cmd.CommandText = "select user_id from users";
            cmd.CommandType = CommandType.Text;

            OracleDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                userIdBox.Items.Add(dr[0]);
            }

            dr.Close();
        }
        private void userIdBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = con;
            cmd.CommandText = "select first_name,last_name,email,user_password,gender,age,user_type from users where user_id = :id";
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.Add("id", userIdBox.SelectedItem.ToString());
            OracleDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                firstNameTxt.Text = dr[0].ToString();
                lastNameTxt.Text = dr[1].ToString();
                emailTxt.Text = dr[2].ToString();
                passwordTxt.Text = dr[3].ToString();
                genderTxt.Text = dr[4].ToString();
                ageTxt.Text = dr[5].ToString();
                userTypeTxt.Text = dr[6].ToString();
            }
            dr.Close();

        }
        private void addUserBtn_Click(object sender, EventArgs e)
        {
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = con;
            cmd.CommandText = "insert into users values(user_id_seq.nextval,:fname,:lname,:email,:pass,:gander,:age,0)";
            // user type default value is 0 because admins are specific not added by form
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.Add("fname", firstNameTxt.Text);
            cmd.Parameters.Add("lname", lastNameTxt.Text);
            cmd.Parameters.Add("email", emailTxt.Text);
            cmd.Parameters.Add("pass", passwordTxt.Text);
            cmd.Parameters.Add("gender", genderTxt.Text);
            cmd.Parameters.Add("age", ageTxt.Text);
            //cmd.Parameters.Add("type",userTypeTxt.Text);

            int r = cmd.ExecuteNonQuery();
            if (r != -1)
            {
                userIdBox.Items.Add(userIdBox.Text);
                MessageBox.Show("New User are ADDED");
            }
        }
        private void updateUserBtn_Click(object sender, EventArgs e)
        {
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = con;
            cmd.CommandText = "update users set first_name = :fname, last_name = :lname , email = :email , user_password = :pass , gender = :gander , age = :age , user_type = :type where user_id = :id";
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.Add("fname", firstNameTxt.Text);
            cmd.Parameters.Add("lname", lastNameTxt.Text);
            cmd.Parameters.Add("email", emailTxt.Text);
            cmd.Parameters.Add("pass", passwordTxt.Text);
            cmd.Parameters.Add("gender", genderTxt.Text);
            cmd.Parameters.Add("age", ageTxt.Text);
            cmd.Parameters.Add("type", userTypeTxt.Text);
            cmd.Parameters.Add("id", userIdBox.SelectedItem.ToString());

            int r = cmd.ExecuteNonQuery();
            if (r != -1)
            {
                userIdBox.Items.Add(userIdBox.Text);
                MessageBox.Show("User are modified");
            }
        }
        private void deleteUserBtn_Click(object sender, EventArgs e)
        {
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = con;
            cmd.CommandText = "delete from users where user_id = :id";
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.Add("id", userIdBox.Text);

            int r = cmd.ExecuteNonQuery();
            if (r != -1)
            {
                MessageBox.Show("user are DELETED");
                userIdBox.Items.RemoveAt(userIdBox.SelectedIndex);
                firstNameTxt.Text = "";
                lastNameTxt.Text = "";
                emailTxt.Text = "";
                passwordTxt.Text = "";
                genderTxt.Text = "";
                ageTxt.Text = "";
                userTypeTxt.Text = "";
            }
        }
        private void addPhoneBtn_Click(object sender, EventArgs e)
        {
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = con;
            cmd.CommandText = "insert into user_phones values (:id,:phone)";
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.Add("id", userIdBox.Text);
            cmd.Parameters.Add("phone", phonesBox.Text);

            int r = cmd.ExecuteNonQuery();
            if (r != -1)
            {
                phonesBox.Items.Add(phonesBox.Text);
                MessageBox.Show("New Phone are ADDED");
            }
        }

        private void showPhonesBtn_Click(object sender, EventArgs e)
        {
            /*
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = con;
            cmd.CommandText = "getPhones";
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("userid", userIdBox.SelectedItem.ToString());
            cmd.Parameters.Add("phone", OracleDbType.Int64 , ParameterDirection.Output);

            OracleDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                phonesBox.Items.Add(dr[0]);
            }

            dr.Close();
            */
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            con.Dispose();
        }

        private void userPhonesReportBtn_Click(object sender, EventArgs e)
        {
            crystalReportViewer1.ReportSource = cr;
        }
    }
}
